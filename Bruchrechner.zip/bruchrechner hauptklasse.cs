﻿using System;
{
    // Variable zum Speichern des letzten Ergebnisses
    static Bruch LetztesErgebnis = null;

    // Hauptmethode des Programms
    static void Main(string[] args)
    {
        // Endlosschleife für die Benutzereingaben
        while (true)
        {
            // Benutzer zur Eingabe einer Rechenoperation oder zum Beenden des Programms auffordern
            Console.WriteLine("Geben Sie eine Rechnung ein (z.B. .../... + .../...) oder 'exit' zum Beenden:");
            string input = Console.ReadLine();

            // Programm beenden, wenn Benutzer 'exit' eingibt
            if (input.ToLower() == "exit")
                break;

            try
            {
                // Eingabe in Teile zerlegen und Bruchobjekte erstellen
                string[] parts = input.Split(' ');
                Bruch operand1 = ParseBruch(parts[0]);
                string operation = parts[1];
                Bruch operand2 = ParseBruch(parts[2]);

                // Berechnung des Ergebnisses basierend auf der Operation
                Bruch result = Berechne(operand1, operation, operand2);
                Console.WriteLine($"Ergebnis: {result}");

                // Letztes Ergebnis speichern
                LetztesErgebnis = result;
            }
            catch (Exception ex)
            {
                // Fehlermeldung anzeigen, wenn eine Ausnahme auftritt
                Console.WriteLine($"Fehler: {ex.Message}");
            }
        }
    }

    // Methode zum Parsen von Benutzereingaben in Bruchobjekte
    static Bruch ParseBruch(string input)
    {
        string[] parts = input.Split('/');
        int zaehler = int.Parse(parts[0]);
        int nenner = int.Parse(parts[1]);
        return new Bruch(zaehler, nenner);
    }

    // Methode zur Durchführung der Rechenoperation basierend auf dem Operator
    static Bruch Berechne(Bruch operand1, string operation, Bruch operand2)
    {
        switch (operation)
        {
            case "+":
                return operand1 + operand2;
            case "-":
                return operand1 - operand2;
            case "*":
                return operand1 * operand2;
            case "/":
                return operand1 / operand2;
            default:
                throw new ArgumentException("Ungültige Operation.");
        }
    }
}